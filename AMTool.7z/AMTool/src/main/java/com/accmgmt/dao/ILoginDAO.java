package com.accmgmt.dao;

public interface ILoginDAO {

	public boolean checkIfUserExists(String userId, String password);

}
