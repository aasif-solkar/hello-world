package com.accmgmt.controller;

import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;

import com.accmgmt.common.CipherUtils;
import com.accmgmt.formbeans.LoginBean;
import com.accmgmt.services.ILoginService;

@ManagedBean(name="loginController")
public class LoginController {
	
	@ManagedProperty("#{loginBean}")
	private LoginBean loginBean;
	
	@ManagedProperty("#{loginService}")
	private ILoginService loginService;
	
	public void doLogin(){
		System.out.println("inside doLogin");
		System.out.println(loginBean.getUserId());
		System.out.println(loginBean.getPassword());
		getLoginService().checkIfUserExists(loginBean.getUserId(), CipherUtils.encrypt(loginBean.getPassword()));
	}

	public LoginBean getLoginBean() {
		return loginBean;
	}

	public void setLoginBean(LoginBean loginBean) {
		this.loginBean = loginBean;
	}

	public ILoginService getLoginService() {
		return loginService;
	}

	public void setLoginService(ILoginService loginService) {
		this.loginService = loginService;
	}
}
