package com.accmgmt.services;

public interface ILoginService {
	public boolean checkIfUserExists(String userId,String password);
}
