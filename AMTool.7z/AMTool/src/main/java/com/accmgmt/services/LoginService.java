package com.accmgmt.services;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.accmgmt.dao.ILoginDAO;

@Component
public class LoginService implements ILoginService{

	@Autowired
	private ILoginDAO loginDAO;
	
	@Override
	public boolean checkIfUserExists(String userId, String password) {
		return loginDAO.checkIfUserExists(userId, password);
	}
	
}
