package com.accmgmt.dao;

import org.springframework.orm.hibernate4.support.HibernateDaoSupport;

public class LoginDAO extends HibernateDaoSupport implements ILoginDAO {

	@Override
	public boolean checkIfUserExists(String userId, String password) {
		// TODO Auto-generated method stub
		return false;
	}
}
